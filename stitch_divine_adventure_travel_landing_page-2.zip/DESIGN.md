---
name: Rugged Refined Expedition
colors:
  surface: '#fff8f6'
  surface-dim: '#fdd0c2'
  surface-bright: '#fff8f6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff1ed'
  surface-container: '#ffe9e3'
  surface-container-high: '#ffe2d9'
  surface-container-highest: '#ffdbcf'
  on-surface: '#2d150d'
  on-surface-variant: '#56423c'
  inverse-surface: '#452a20'
  inverse-on-surface: '#ffede8'
  outline: '#8a726b'
  outline-variant: '#ddc0b8'
  surface-tint: '#9f4021'
  primary: '#9c3e1f'
  on-primary: '#ffffff'
  primary-container: '#bc5634'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb59e'
  secondary: '#9a442a'
  on-secondary: '#ffffff'
  secondary-container: '#fd9171'
  on-secondary-container: '#752811'
  tertiary: '#7c5400'
  on-tertiary: '#ffffff'
  tertiary-container: '#9c6b00'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbd0'
  primary-fixed-dim: '#ffb59e'
  on-primary-fixed: '#3a0b00'
  on-primary-fixed-variant: '#802a0b'
  secondary-fixed: '#ffdbd1'
  secondary-fixed-dim: '#ffb5a0'
  on-secondary-fixed: '#3b0a00'
  on-secondary-fixed-variant: '#7c2e16'
  tertiary-fixed: '#ffdeae'
  tertiary-fixed-dim: '#fbbb4f'
  on-tertiary-fixed: '#281900'
  on-tertiary-fixed-variant: '#604100'
  background: '#fff8f6'
  on-background: '#2d150d'
  surface-variant: '#ffdbcf'
typography:
  display-hero:
    fontFamily: Fraunces
    fontSize: 110px
    fontWeight: '600'
    lineHeight: 104px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Fraunces
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 52px
    letterSpacing: -0.02em
  headline-xl:
    fontFamily: Fraunces
    fontSize: 64px
    fontWeight: '600'
    lineHeight: 72px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Fraunces
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Fraunces
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Fraunces
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Fraunces
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-accent-italic:
    fontFamily: Fraunces
    fontSize: 24px
    fontWeight: '400'
    lineHeight: 32px
  body-lg:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-sm:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Manrope
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Manrope
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Manrope
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.06em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 4rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
  space-2xl: 4rem
  space-3xl: 6rem
---

## Brand & Style

This design system embodies "rugged refinement"—an aesthetic convergence of bespoke high-altitude exploration and warm, tactile luxury. Built for seasoned travelers seeking extraordinary, curated expeditions, the interface balances raw geological endurance with tailored hospitality.

The design language moves away from generic, sterile booking engines in favor of immersive editorial storytelling. Full-bleed expedition imagery is grounded by hand-crafted organic textures: subtle topographic vector contours, deckle-edge/torn-paper transitional dividers, and warm, sunlight-baked mineral tones. The tactile presence mirrors physical expedition journals and heritage field gear, while clean pill-shaped interactions guarantee frictionless utility.

## Colors

The palette draws directly from high desert plateaus, alpine granite, and sun-baked canyon clay.

- **Primary (`#C65D3B` Terracotta):** Represents vitality, baked earth, and warm sunrise rock. Applied to primary calls-to-action, key interactive elements, and focal journey highlights.
- **Deep Accent (`#8E3B22` Burnt Sienna):** An intensely saturated mineral tone used for hover states, high-priority visual anchors, badges, and contrasting dark container surfaces.
- **Warm Gold (`#E0A43A`):** Reserved for prestige indicators, review stars, bespoke badges, award laurels, and rare expedition advisories.
- **Surfaces:** Dual-base foundation alternating between Sand Cream (`#F7EFE4`) for editorial warmth and Pure White (`#FFFFFF`) for crisp, data-dense itinerary layouts.
- **Typography & Contrasts:** Deep Brown (`#3B2118`) provides high-contrast legibility across light surfaces without the stark harshness of pure black. In dark or inverted layouts (such as hero viewports and nocturnal camp overviews), text flips strictly to Sand Cream (`#F7EFE4`).

## Typography

The typographic hierarchy pairs the editorial, humanistic character of `Fraunces` with the clean, neutral mechanics of `Manrope`.

- **Fraunces:** Primary display serif. Employed across large promotional statements, destination titles, and narrative introductions. Fraunces Italic (`headline-accent-italic`) introduces intimate, bespoke travel notes and editorial excerpts within photo spreads.
- **Manrope:** Functional sans-serif driving body copy, pricing indices, technical equipment checklists, tabular day-by-day itineraries, and interactive controls. Manrope 600 brings confident weight and clarity to pill buttons, interactive tags, and micro-labels.

## Layout & Spacing

The layout is built on a responsive 12-column fluid grid system on desktop that transitions to 8 columns on tablet and 4 columns on mobile viewports.

- **Desktop (>= 1280px):** 12 columns with `4rem` outer canvas margins and `1.5rem` gutters. Section vertical spacing expands to `space-3xl` (`6rem`) to create dramatic, full-bleed vistas.
- **Tablet (768px - 1279px):** 8 columns, `2rem` outer margins, `1rem` gutters. Cards and journey routes arrange in 2-column matrices.
- **Mobile (< 768px):** 4 columns, `1.25rem` outer margins, `1rem` gutters. Full-width horizontal swipe carousels replace multi-column gallery grids.
- **Torn Paper Dividers:** SVG-driven mask cutouts with jagged, deckle-edge silhouettes separate contrasting Sand Cream and Burnt Sienna sections, breaking uniform grid lines with hand-crafted natural transitions.

## Elevation & Depth

Visual hierarchy rejects generic dropshadows in favor of tonal layering, geological ambient occlusion, and subtle linework:

- **Tonal Layers:** Surfaces rise visually by layering Pure White (`#FFFFFF`) cards atop the Sand Cream (`#F7EFE4`) background, framed with low-contrast borders (`rgba(59, 33, 24, 0.08)`).
- **Warm Earth Ambient Shadows:** Elevated components (floating navigation bars, modal itineraries, hovering cards) cast an ultra-soft, diffused shadow tinted with Deep Brown: `0 12px 36px -4px rgba(59, 33, 24, 0.12)`.
- **Topographic Vectors:** Intricate topographic contour lines rendered at 4% to 8% opacity in Deep Brown sit directly behind cards, creating an authentic cartographic sense of physical depth.

## Shapes

The design system uses a Level 3 (pill-shaped) geometry for all actionable elements (buttons, filter chips, navigation bars, and badging). This rounded language creates a sleek, modern counterpoint to the raw, jagged hand-torn paper borders and mountainous photography.

- **Buttons & Pills:** Full capsule rounding (`border-radius: 9999px`).
- **Cards & Visual Containers:** Soft, balanced boundaries (`border-radius: 1.25rem` to `1.5rem`) to maintain architectural structure while keeping corners welcoming and tactile.

## Components

- **Pill Navigation:** A floating dock anchored to the viewport top or floating bottom-center. Rendered in Sand Cream (`#F7EFE4`) or Pure White (`#FFFFFF`) with a warm ambient shadow, fully pill-shaped (`rounded-full`), featuring Manrope 600 labels and a compact Terracotta primary action button.
- **Buttons:**
  - *Primary:* Terracotta (`#C65D3B`) fill, Sand Cream (`#F7EFE4`) text, full pill curvature, transitioning to Burnt Sienna (`#8E3B22`) on hover.
  - *Secondary / Outlined:* Pure White or Sand Cream base, 1.5px Deep Brown (`#3B2118`) border, Deep Brown text.
  - *Ghost / Editorial:* Text with subtle arrow glyphs, featuring Fraunces Italic transitions.
- **Expedition Cards:** Pure White surface, `1.5rem` border radius, subtle Deep Brown border at 8% opacity. Features full-bleed ratio imagery on top, Warm Gold badge tags in the top corner, and clean Manrope pricing/duration specs along the bottom edge.
- **Chips & Filter Pills:** Fully rounded, Manrope 600 font, low-profile padding (`0.5rem 1rem`). Inactive state is transparent with a thin warm sand border; active state is solid Burnt Sienna with Sand Cream text.
- **Inputs & Fields:** Pill or soft-radius containers (`rounded-xl`), Sand Cream or White background, Deep Brown placeholder copy at 50% opacity, shifting to a 2px Terracotta outline on focus.
- **Checkboxes & Radios:** Pill-inspired circular indicators, deep brown unselected border, terracotta fill when active with pure white custom iconography.
- **Torn Paper Breaks:** Seamless vector-based section dividers injected between high-contrast editorial blocks, providing an organic, handcrafted expedition feel.